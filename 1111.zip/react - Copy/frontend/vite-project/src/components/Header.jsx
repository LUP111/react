import { FaSignInAlt, FaSignOutAlt, FaUser } from 'react-icons/fa'
import { Link, useNavigate} from 'react-router';
import { useSelector, useDispatch } from 'react-redux';

const Header = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const user = useSelector(state => state.user);

    const handleLogout = () => {
        dispatch(logoutUser());
        navigate('/');
    }
 return (
 <header className='header'>
 <div className="logo">
<Link to='/'>Task Creator</Link>
 </div>
 <ul>
{user ? (
    <li>
<button classname='btn' onClick={handleLogout}>
    <FaSignOutAlt /> Logout
</button>
    </li>
) : (
<>
<li>
    <Link to='/login'><FaSignOutAlt /> Login</Link>
</li>
<li>
    <Link to='.register'><FaUser /> Register</Link>
</li>
</>
)}
 </ul>
 </header>
 )
}
export default Header
