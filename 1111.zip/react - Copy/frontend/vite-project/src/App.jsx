import { BrowserRouter, Routes, Route } from "react-router";

import Dashboard from "./components/dashboard";
import Login from "./components/Login";
import Register from "./components/Register";
import Tasklist from "./components/TaskList";

import Header from "./components/Register";
import { ToastContainer } from "react-toastify";
import 'react=toastify/dist/ReactToastify.css'


function App() {
 return (
  <>
<BrowserRouter>
 <div className='container'>
  <Header />
<Routes>
  <Route path="/" element={<Dashboard />} />
  <Route path="/login" element={<Login />} />
  <Route path="/register" element={<Register />} />
  <Route path='allTasks' element={<TaskList />} />
 </Routes>
</div>
 </BrowserRouter>
 <ToastContainer />
 </>
);
}
export default App
